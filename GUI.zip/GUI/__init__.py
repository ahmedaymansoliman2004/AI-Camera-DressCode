# In main_window.py
# These imports will now work correctly because of __init__.py
from .video_thread import VideoThread
from .inference_engine import InferenceEngine
from .audit_logger import AuditLogger  # <-- Import the new class

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        # ...
        self.audit_logger = AuditLogger()  # <-- Initialize it here
        # ...