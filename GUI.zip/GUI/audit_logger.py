# app/audit_logger.py
import sqlite3
import json
import cv2
import time
from pathlib import Path

class AuditLogger:
    def __init__(self, db_path: str = "audit_log.db"):
        self.db_path = db_path
        self.thumbnail_dir = Path("thumbnails")
        self.thumbnail_dir.mkdir(exist_ok=True)  # Create dir if it doesn't exist
        self._init_db()

    def _init_db(self):
        """Initializes the database table if it doesn't exist."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS audit_events (
                id INTEGER PRIMARY KEY,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                thumbnail_path TEXT,
                original_detections TEXT,
                is_flagged BOOLEAN,
                is_reviewed BOOLEAN DEFAULT FALSE,
                review_action TEXT,
                corrected_class TEXT
            )
        ''')
        conn.commit()
        conn.close()

    def _blur_faces(self, frame: np.ndarray) -> np.ndarray:
        """A simple function to blur faces for privacy (placeholder)."""
        # For a real implementation, you would use a face detection model here first.
        # This is a simplified version that blurs the entire frame.
        return cv2.GaussianBlur(frame, (99, 99), 30)

    def _save_thumbnail(self, frame: np.ndarray) -> str:
        """Saves a blurred, low-resolution thumbnail. Returns the file path."""
        blurred_frame = self._blur_faces(frame)
        small_frame = cv2.resize(blurred_frame, (160, 120))
        filename = self.thumbnail_dir / f"{int(time.time())}.jpg"
        cv2.imwrite(str(filename), small_frame)
        return str(filename)

    def log_event(self, frame: np.ndarray, detections: list, is_flagged: bool):
        """Logs an event to the database. Saves a thumbnail only for flagged events."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        thumbnail_path = None
        if is_flagged:
            thumbnail_path = self._save_thumbnail(frame)

        # Convert detections list to JSON string for storage
        detections_json = json.dumps(detections)

        cursor.execute('''
            INSERT INTO audit_events (thumbnail_path, original_detections, is_flagged)
            VALUES (?, ?, ?)
        ''', (thumbnail_path, detections_json, is_flagged))

        conn.commit()
        conn.close()

    def get_review_items(self) -> list:
        """Fetches all events that need review (is_reviewed is FALSE)."""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row  # This enables column access by name
        cursor = conn.cursor()

        cursor.execute('''
            SELECT id, timestamp, thumbnail_path, original_detections
            FROM audit_events
            WHERE is_reviewed = FALSE
            ORDER BY timestamp DESC
        ''')

        rows = cursor.fetchall()
        conn.close()
        return rows

    def update_review_status(self, event_id: int, action: str, corrected_class: str = None):
        """Updates an event after human review."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute('''
            UPDATE audit_events
            SET is_reviewed = TRUE, review_action = ?, corrected_class = ?
            WHERE id = ?
        ''', (action, corrected_class, event_id))

        conn.commit()
        conn.close()