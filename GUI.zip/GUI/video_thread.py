from PyQt5.QtCore import QThread, pyqtSignal
from picamera2 import Picamera2
import cv2

class VideoThread(QThread):
    change_pixmap_signal = pyqtSignal(object)  # Emits numpy array (frame)
    new_detection_signal = pyqtSignal(list, bool)  # Emits (detections, is_flagged)

    def __init__(self, inference_engine):
        super().__init__()
        self.inference_engine = inference_engine
        self.conf_threshold = 0.7
        self.is_running = True
        self.picam2 = Picamera2()
        self.preview_config = self.picam2.create_preview_configuration(main={"size": (640, 480)})
        self.picam2.configure(self.preview_config)

    def run(self):
        self.picam2.start()
        while self.is_running:
            frame = self.picam2.capture_array() 
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            
            # Run Inference
            detections = self.inference_engine.process_frame(rgb_frame)
            is_flagged = any(d['confidence'] > self.conf_threshold for d in detections)
            
            # Emit Signals
            self.new_detection_signal.emit(detections, is_flagged)
            self.change_pixmap_signal.emit(rgb_frame) # Emit the frame for drawing

    def stop(self):
        self.is_running = False
        self.picam2.stop()
        self.wait() # Wait for the thread to finish