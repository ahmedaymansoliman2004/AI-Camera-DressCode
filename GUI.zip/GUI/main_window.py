from PyQt5.QtWidgets import QMainWindow, QLabel, QVBoxLayout, QWidget, QPushButton, QSlider, QHBoxLayout, QApplication
from PyQt5.QtCore import Qt, pyqtSlot
from PyQt5.QtGui import QImage, QPixmap, QPainter, QPen, QColor
import sys
import numpy as np

# Import our custom classes
from .video_thread import VideoThread
from .inference_engine import InferenceEngine
from .audit_logger import AuditLogger

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("AI Dress Code Monitor")
        self.setGeometry(100, 100, 1000, 600)
        
        # Initialize Core Components
        self.inference_engine = InferenceEngine(model_path="../models/best.onnx")
        self.audit_logger = AuditLogger()
        self.video_thread = VideoThread(self.inference_engine)
        
        # Current state
        self.current_detections = []
        self.conf_threshold = 0.7
        
        # Setup UI
        self.setup_ui()
        
        # Connect Signals and Slots
        self.video_thread.change_pixmap_signal.connect(self.update_image)
        self.video_thread.new_detection_signal.connect(self.log_and_update_ui)
        
        # Start the video thread
        self.video_thread.start()

    def setup_ui(self):
        # Central Widget and Layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QHBoxLayout(central_widget)
        
        # Video Feed on the left
        self.video_label = QLabel()
        self.video_label.setMinimumSize(640, 480)
        self.video_label.setAlignment(Qt.AlignCenter)
        self.video_label.setText("Starting camera...")
        layout.addWidget(self.video_label)
        
        # Right Panel for Dashboard (simplified for now)
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        
        self.status_label = QLabel("Status: Live")
        self.violation_count_label = QLabel("Violations (today): 0")
        
        right_layout.addWidget(self.status_label)
        right_layout.addWidget(self.violation_count_label)
        right_layout.addStretch()
        
        layout.addWidget(right_panel)
        
        # Control Bar at the bottom (simplified)
        self.pause_button = QPushButton("Pause")
        self.threshold_slider = QSlider(Qt.Horizontal)
        self.threshold_slider.setRange(0, 100)
        self.threshold_slider.setValue(70) # 70%
        
        control_layout = QHBoxLayout()
        control_layout.addWidget(self.pause_button)
        control_layout.addWidget(QLabel("Conf Threshold:"))
        control_layout.addWidget(self.threshold_slider)
        
        layout.addLayout(control_layout)

    @pyqtSlot(np.ndarray)
    def update_image(self, rgb_frame: np.ndarray):
        """Draws bounding boxes on the frame and displays it."""
        height, width, channels = rgb_frame.shape
        bytes_per_line = channels * width
        
        # Convert numpy array to QImage for display
        qt_image = QImage(rgb_frame.data, width, height, bytes_per_line, QImage.Format_RGB888)
        pixmap = QPixmap.fromImage(qt_image)
        
        # Draw on the pixmap
        painter = QPainter(pixmap)
        pen = QPen(QColor(255, 0, 0))
        pen.setWidth(3)
        painter.setPen(pen)
        font = painter.font()
        font.setPointSize(12)
        painter.setFont(font)

        for detection in self.current_detections:
            if detection['confidence'] > self.conf_threshold:
                x1, y1, x2, y2 = detection['bbox']
                rect = QColor(int(x1), int(y1), int(x2-x1), int(y2-y1))
                painter.drawRect(rect)
                label = f"{detection['class_name']}: {detection['confidence']:.2f}"
                painter.drawText(int(x1), int(y1)-5, label)
        
        painter.end()
        
        # Scale and set the pixmap
        self.video_label.setPixmap(pixmap.scaled(640, 480, Qt.KeepAspectRatio))

    @pyqtSlot(list, bool)
    def log_and_update_ui(self, detections: list, is_flagged: bool):
        """Stores the latest detections and logs them."""
        self.current_detections = detections
        # TODO: Call self.audit_logger.log_event(...)
        # For now, just update the UI with the count
        violation_count = sum(1 for d in detections if d['confidence'] > self.conf_threshold)
        self.violation_count_label.setText(f"Violations (now): {violation_count}")

    def closeEvent(self, event):
        """Ensures the video thread is stopped when the window is closed."""
        self.video_thread.stop()
        event.accept()

# This block is only for testing this file directly
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())